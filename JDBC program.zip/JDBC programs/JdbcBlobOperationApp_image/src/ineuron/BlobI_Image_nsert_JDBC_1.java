/*
package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Insert_JDBC_3 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        String imageLoc=null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	
	        	String sqlInsertQuery = "insert into persons(name,image)values(?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        		//Read the input from the user
	    	        System.out.print("Enter the name of the student :: ");
	    	        String name =scan.next();
	    	      
	    	        System.out.print("Enter image location :: ");
	    	        imageLoc =scan.next();
	    			
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, name);
	        	   pstmt.setBinaryStream(2, new FileInputStream(new File(imageLoc)));
	        	   
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}
*/


//adding video

package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;



public class BlobI_Image_nsert_JDBC_1 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        String imageLoc=null;
	        String  videoLoc= null;
	        String  audioLoc= null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	
	        	String sqlInsertQuery = "insert into persons(name,image,video,audio)values(?,?,?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        		//Read the input from the user
	    	        System.out.print("Enter the name of the student :: ");
	    	        String name =scan.next();
	    	      
	    	        System.out.print("Enter image location :: ");
	    	        imageLoc =scan.next();
	    	        
	    	        System.out.print("Enter video location :: ");
	    	        videoLoc =scan.next();
	    	        
	    	        System.out.print("Enter video audio :: ");
	    	        audioLoc =scan.next();
	    			
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, name);
	        	   pstmt.setBinaryStream(2, new FileInputStream(new File(imageLoc)));
	        	   pstmt.setBinaryStream(3, new FileInputStream(new File(videoLoc)));
	        	   pstmt.setBinaryStream(4, new FileInputStream(new File(audioLoc)));
	        	   
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        //	D:\Images\Sam.jpeg
	        //	D:\Video\Samv.mp4
	       //   D:\Audio\seal.mp3
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}


















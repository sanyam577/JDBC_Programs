
package ineuron;
import java.io.IOException;
import java.io.*;
import java.sql.*;

import java.util.Scanner;

import org.apache.commons.io.IOUtils;

import ineuronutil.jdbcutil;



public class Blob_Image_Retrival_JDBC2   {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        ResultSet resultSet=null;
	        int id=0;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlSelectQuery = "select id, name, image from persons where id=?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlSelectQuery);
	        	
	        	if(pstmt!=null) {
	        		
                    scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the id of the student :: ");
	    	         id =scan.nextInt();
	        
	        		//use recompiled query to set values
	        	   pstmt.setInt(1, id);
	        	   
	        	   
	        	   resultSet =pstmt.executeQuery();
	        	   if(resultSet!=null) {
		      
		        		if(resultSet.next()) {
		        			System.out.println("ID\tNAME\tSIMAGE");
		                     id = resultSet.getInt(1);
		                    String name =resultSet.getNString(2);
		                    InputStream is = resultSet.getBinaryStream(3);  //is means inputStream
		                    
		                 File file = new File("copied.jpg");
		                 FileOutputStream fos = new FileOutputStream(file);
		                
		                 /*
		                 int i = is.read();   //this process is bit slow because it read one line and then transfer it 
		                 while(i!=-1) {
		                	 fos.write(i);
		                	 i=is.read();
		                 }
		                 
		                  
		                 //now this will be faster than the previous one
		                 byte[] b = new byte[1024]; 
		                 while(is.read(b)>0) { //Reads some number of bytes from the input stream and stores them into the buffer array b.
		                	 fos.write(b);         //If the length of b is zero, then no bytes are read and 0 is returned 
		                 }
		                 */
		                 
		                 //this is third process here we are going to use third part api or external jar to read the data
		                
		                 IOUtils.copy(is,fos);
		                 fos.close();   
		        		System.out.println(id+"\t"+name+"\t"+ file.getAbsolutePath());
		        		}
		        		
		        		else {
		        			System.out.println("Record not found of this id ::"+id);
		        		}
		        	}
	        	   
	        	}
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, resultSet);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	}
}


package ineuron;
import java.util.*;
import ineuronutil.jdbcutil;
import java.io.*;
import java.sql.*;



public class Project {

	public static void main(String[] args) {
		Connection connection = null;
        PreparedStatement pstmt = null;
        Scanner scan = null;
        ResultSet resultSet=null;
        int sid=0;
		
		
		  scan = new Scanner(System.in);
		  System.out.println("Enter a number for CURD operation");
          int n = scan.nextInt();
      
		
             
		if(n==1) {
		
			 try {
		        	connection =jdbcutil.getJdbcConnection();
		        	System.out.println("connection established");
		        	
		        	String sqlInsertQuery = "insert into student(sname,sage,address)values(?,?,?)";
		        	if(connection!=null)
		        		pstmt =connection.prepareStatement(sqlInsertQuery);
		        	if(pstmt!=null) {
		        		scan = new Scanner(System.in);
		    	        
		    	        System.out.print("Enter the name of the student :: ");
		    	        String sname =scan.next();
		    	        
		    	        System.out.print("Enter the age of the student :: ");
		    	        int sage =scan.nextInt();
		    	        
		    	        System.out.print("Enter the address of the student :: ");
		    	        String address =scan.next();
		        		
		        		
		        		
		        		
		        		//use recompiled query to set values
		        	   pstmt.setNString(1, sname);
		        	   pstmt.setInt(2, sage);
		        	   pstmt.setNString(3, address);
		        	   
		        	   System.out.println(sqlInsertQuery);
		        	   //execute the query
		        	   int rowCount =pstmt.executeUpdate();
		        	   System.out.println("No of rows updated is :: "+rowCount);
		        	   
		        	}
		        	  	
		        }
		        catch(IOException i) {
		        	i.printStackTrace();
		        	}
		        catch(SQLException se) {
		        	se.printStackTrace();
		        }catch(Exception e) {
		        	e.printStackTrace();
		        	}
		        finally {
		        	try {
						jdbcutil.cleanUp(connection, pstmt, null);
						scan.close();
						System.out.println("closing the resources");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
			
		}
		
		else if(n==2) {
			
			try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlSelectQuery = "select sid ,sname, sage, address from student where sid=?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlSelectQuery);
	        	
	        	if(pstmt!=null) {
	        		
                    scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the id of the student :: ");
	    	         sid =scan.nextInt();
	        
	        		//use recompiled query to set values
	        	   pstmt.setInt(1, sid);
	        	   
	        	   
	        	   resultSet =pstmt.executeQuery();
	        	   if(resultSet!=null) {
		      
		        		if(resultSet.next()) {
		        			System.out.println("SID\tSNAME\tSAGE\tADDRESS");
		        			System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getString(4)); //select the variable and then press alt shift I (it will make the code inline)
		        		
		        		}
		        		
		        		else {
		        			System.out.println("Record not found of this id ::"+sid);
		        		}
		        	}
	        	   
	        	}
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, resultSet);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
			
			
		}
		else if(n==3) {
			
			 try {
		        	connection =jdbcutil.getJdbcConnection();
		        	System.out.println("connection established");
		        	
		        	String sqlUpdateQuery = "update student set address =? where sid= ?";
		        	if(connection!=null)
		        		pstmt =connection.prepareStatement(sqlUpdateQuery);
		        	if(pstmt!=null) {
		        		scan = new Scanner(System.in);
		    	        
		    	        System.out.print("Enter the address of the student :: ");
		    	        String address =scan.next();
		    	        
		    	        System.out.print("Enter the id of the student :: ");
		    	         sid =scan.nextInt();
		    	  
		        		
		        		//use recompiled query to set values
		        	   pstmt.setNString(1, address);
		        	   pstmt.setInt(2, sid);
		        	  
		        	   
		        	   System.out.println(sqlUpdateQuery);
		        	   //execute the query
		        	   int rowCount =pstmt.executeUpdate();
		        	   System.out.println("No of rows updated is :: "+rowCount);
		        	   
		        	}
		        	  	  	
		        }
		        catch(IOException i) {
		        	i.printStackTrace();
		        	}
		        catch(SQLException se) {
		        	se.printStackTrace();
		        }catch(Exception e) {
		        	e.printStackTrace();
		        	}
		        finally {
		        	try {
						jdbcutil.cleanUp(connection, pstmt, null);
						scan.close();
						System.out.println("closing the resources");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		        
		       
		}
		else if(n==4) {
			
			 try {
		        	connection =jdbcutil.getJdbcConnection();
		        	System.out.println("connection established");
		        	
		        	String sqlDeleteQuery = "delete from student  where sid= ?";
		        	if(connection!=null)
		        		pstmt =connection.prepareStatement(sqlDeleteQuery);
		        	if(pstmt!=null) {
		        		scan = new Scanner(System.in);
		    	        
		    	        System.out.print("Enter the id of the student :: ");
		    	         sid =scan.nextInt();
		    	  
		        		
		        		//use recompiled query to set values
		        	     pstmt.setInt(1, sid);
		        	  
		        	   
		        	   System.out.println(sqlDeleteQuery);
		        	   //execute the query
		        	   int rowCount =pstmt.executeUpdate();
		        	   System.out.println("No of rows delete is :: "+rowCount);
		        	   
		        	}
		        	
		        	
		        	  	
		        }
		        catch(IOException i) {
		        	i.printStackTrace();
		        	}
		        catch(SQLException se) {
		        	se.printStackTrace();
		        }catch(Exception e) {
		        	e.printStackTrace();
		        	}
		        finally {
		        	try {
						jdbcutil.cleanUp(connection, pstmt, null);
						scan.close();
						System.out.println("closing the resources");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		}
		else {
			System.out.println("Enter number between 1 to 4");
		}
		

	}

}

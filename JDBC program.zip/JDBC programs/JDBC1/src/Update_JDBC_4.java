import java.sql.*;

public class Update_JDBC_4{

	public static void main(String[] args) throws ClassNotFoundException , SQLException{
		
		 String url ="jdbc:mysql:///octbatch";  //protocolName:dbenginename://ipaddress of db:portNoOfDb/dbName
	        String userName="root";
	        String passWord="Kalhans8400@";
	        Connection connection = DriverManager.getConnection(url,userName,passWord); //this method is present in class Driver class which implements mysqljar interface
	        System.out.println("the implementation class name is "+connection.getClass().getName());
	        
	        //Step-3 Create statement Object and send the query
	        Statement statement = connection.createStatement();
	        System.out.println("The implementation class name is "+statement.getClass().getName());
	        
	        String sqlUpdateQuery = "update student set address = 'basti' where sid = 1";
	        int rowAffected = statement.executeUpdate(sqlUpdateQuery);
	       System.out.println("No. of affected rows "+rowAffected);
	        
	        //Step-4 Process the result
	      
			statement.close();
			connection.close();

	}

}
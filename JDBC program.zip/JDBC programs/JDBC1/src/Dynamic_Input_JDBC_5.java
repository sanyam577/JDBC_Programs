import java.sql.*;
import java.util.Scanner;

/*
//1st approach
public class Dynamic_Input_JDBC_5 {

	public static void main(String[] args) throws ClassNotFoundException , SQLException{
		
		 String url ="jdbc:mysql:///octbatch";  //protocolName:dbenginename://ipaddress of db:portNoOfDb/dbName
	        String userName="root";
	        String passWord="Kalhans8400@";
	        Connection connection = DriverManager.getConnection(url,userName,passWord); //this method is present in class Driver class which implements mysqljar interface
	        System.out.println("the implementation class name is "+connection.getClass().getName());
	        
	        //Step-3 Create statement Object and send the query
	        Statement statement = connection.createStatement();
	        System.out.println("The implementation class name is "+statement.getClass().getName());
	        
	        Scanner scan = new Scanner(System.in);
	        
	        System.out.print("Enter the name of the student :: ");
	        String sname =scan.next();
	        
	        System.out.print("Enter the age of the student :: ");
	        int sage =scan.nextInt();
	        
	        System.out.print("Enter the address of the student :: ");
	        String address =scan.next();
	        
	        String sqlInsertQuery = "insert into student(sname,sage,address)values('" +sname+ "'," +sage+ ",'" +address+ "')";
	        int rowAffected = statement.executeUpdate(sqlInsertQuery);
	        System.out.println(sqlInsertQuery);
	       System.out.println("No. of affected rows "+rowAffected);
	        
	        //Step-4 Process the result
	      
			statement.close();
			connection.close();

	}

}
*/

/*
//2nd approach

public class Dynamic_Input_JDBC_5 {

	public static void main(String[] args) throws ClassNotFoundException , SQLException{
		
		 String url ="jdbc:mysql:///octbatch";  //protocolName:dbenginename://ipaddress of db:portNoOfDb/dbName
	        String userName="root";
	        String passWord="Kalhans8400@";
	        Connection connection = DriverManager.getConnection(url,userName,passWord); //this method is present in class Driver class which implements mysqljar interface
	        System.out.println("the implementation class name is "+connection.getClass().getName());
	        
	        //Step-3 Create statement Object and send the query
	        Statement statement = connection.createStatement();
	        System.out.println("The implementation class name is "+statement.getClass().getName());
	        
	        Scanner scan = new Scanner(System.in);
	        
	        System.out.print("Enter the name of the student :: ");
	        String sname =scan.next();
	        
	        System.out.print("Enter the age of the student :: ");
	        int sage =scan.nextInt();
	        
	        System.out.print("Enter the address of the student :: ");
	        String address =scan.next();
	        
	        sname="'" +sname+ "'";
	        address="'" +address+ "'";
	        String sqlInsertQuery = "insert into student(sname,sage,address)values("+sname+","+sage+","+address+")";
	        int rowAffected = statement.executeUpdate(sqlInsertQuery);
	        System.out.println(sqlInsertQuery);
	       System.out.println("No. of affected rows "+rowAffected);
	        
	        //Step-4 Process the result
	      
			statement.close();
			connection.close();

	}

}
*/


//3rd approach

public class Dynamic_Input_JDBC_5 {

	public static void main(String[] args) throws ClassNotFoundException , SQLException{
		
		 String url ="jdbc:mysql:///octbatch";  //protocolName:dbenginename://ipaddress of db:portNoOfDb/dbName
	        String userName="root";
	        String passWord="Kalhans8400@";
	        Connection connection = DriverManager.getConnection(url,userName,passWord); //this method is present in class Driver class which implements mysqljar interface
	        System.out.println("the implementation class name is "+connection.getClass().getName());
	        
	        //Step-3 Create statement Object and send the query
	        Statement statement = connection.createStatement();
	        System.out.println("The implementation class name is "+statement.getClass().getName());
	        
	        Scanner scan = new Scanner(System.in);
	        
	        System.out.print("Enter the name of the student :: ");
	        String sname =scan.next();
	        
	        System.out.print("Enter the age of the student :: ");
	        int sage =scan.nextInt();
	        
	        System.out.print("Enter the address of the student :: ");
	        String address =scan.next();
	        
	        String sqlInsertQuery = String.format("insert into student(sname,sage,address)values('%s',%d,'%s')",sname,sage,address);
	        int rowAffected = statement.executeUpdate(sqlInsertQuery);
	        System.out.println(sqlInsertQuery);
	       System.out.println("No. of affected rows "+rowAffected);
	        
	        //Step-4 Process the result
	      
			statement.close();
			connection.close();

	}

}





package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Dynamic_Input_JDBC_5 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement statement = null;
	        ResultSet resultSet = null;
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	
	        	if(connection!=null)
	        		statement =connection.createStatement();
	        	if(statement!=null)
	        		resultSet=statement.executeQuery("select sid,sname,sage,address from student");
	        	if(resultSet!=null) {
	        		System.out.println("SID\tSNAME\tSAGE\tADDRESS");
	        	//	System.out.printf("%2s%14s%12s%15s","SID","SNAME","SAGE","ADDRESS");
	        		while(resultSet.next()) {
	        			System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getString(4)); //select the variable and then press alt shift I (it will make the code inline)
	        		//System.out.printf("%2d%15s%12d%15s",resultSet.getInt(1),resultSet.getString(2),resultSet.getInt(3),resultSet.getString(4));
	        		}
	        	}
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, statement, resultSet);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	System.out.println("closing the resources");
	        }
	        
	       

	}

}





package ineuron;

import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;


public class Insert_JDBC_1 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	
	        	String sqlInsertQuery = "insert into users(name,dob)values(?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        		//Read the input from the user
	    	        System.out.print("Enter the name of the student :: ");
	    	        String name =scan.next();
	    	      
	    			System.out.println("Enter the dob:: (dd-MM-yyyy)");
	    			String dob1 = scan.next();
	    			
	    			//Convert the date from String format to java.util.Date
	    			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); //SimpleDateFormat is a concrete class
	    		    java.util.Date uDate = sdf.parse(dob1);	                    //for formatting and parsing dates in a locale-sensitive manner. 
	    			
	    	        //Convert java.util.Date into java.sql.Date
	    		    long value = uDate.getTime();
	    		    java.sql.Date dob =new java.sql.Date(value);
	    		  
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, name);
	        	   pstmt.setDate(2, dob);
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        		  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}



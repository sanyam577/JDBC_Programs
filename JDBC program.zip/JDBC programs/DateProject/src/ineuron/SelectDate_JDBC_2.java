package ineuron;

import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;


public class SelectDate_JDBC_2 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        ResultSet resultSet=null;
	        Scanner scan = null;
	        int id=1;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	
	        	String sqlSelectQuery = "select name,dob,dom from users where id=?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlSelectQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        	
				//Read the input from the user
	    	       pstmt.setInt(1,  id);
	    	       
	    	       resultSet =pstmt.executeQuery(); 
	        	}
	        	if(resultSet!=null) {
	        		
	        		//processing the result
	        		if(resultSet.next()) {
	        			System.out.println("NAME\tDOB\tDOM");
	        			String name = resultSet.getNString(1);
	        			java.sql.Date dob = resultSet.getDate(2);
	        			java.sql.Date dom = resultSet.getDate(3);
	        			
	        			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	        			String strDob = sdf.format(dob);
	        			String strDom = sdf.format(dom);
	        			
	        			System.out.println(name+"\t"+strDob+"\t"+strDom);	
	        		}
	        		else {
	        			System.out.println("Record not available for the given id :: "+id);
	        		}
	        	}
	        		  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}



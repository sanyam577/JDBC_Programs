package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Delete_App_Dynamic_Input_JDBC_5 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlDeleteQuery = "delete from student  where sid= ?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlDeleteQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the id of the student :: ");
	    	        int sid =scan.nextInt();
	    	  
	        		
	        		//use recompiled query to set values
	        	     pstmt.setInt(1, sid);
	        	  
	        	   
	        	   System.out.println(sqlDeleteQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows delete is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}











package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class  Select_App_Dynamic_Input_JDBC_3 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        ResultSet resultSet=null;
	        int sid=0;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlSelectQuery = "select sid ,sname, sage, address from student where sid=?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlSelectQuery);
	        	
	        	if(pstmt!=null) {
	        		
                    scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the id of the student :: ");
	    	         sid =scan.nextInt();
	        
	        		//use recompiled query to set values
	        	   pstmt.setInt(1, sid);
	        	   
	        	   
	        	   resultSet =pstmt.executeQuery();
	        	   if(resultSet!=null) {
		      
		        		if(resultSet.next()) {
		        			System.out.println("SID\tSNAME\tSAGE\tADDRESS");
		        			System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getString(4)); //select the variable and then press alt shift I (it will make the code inline)
		        		
		        		}
		        		
		        		else {
		        			System.out.println("Record not found of this id ::"+sid);
		        		}
		        	}
	        	   
	        	}
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, resultSet);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	}
}





package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Insert_App_Dynamic_Input_JDBC_2 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlInsertQuery = "insert into student(sname,sage,address)values(?,?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the name of the student :: ");
	    	        String sname =scan.next();
	    	        
	    	        System.out.print("Enter the age of the student :: ");
	    	        int sage =scan.nextInt();
	    	        
	    	        System.out.print("Enter the address of the student :: ");
	    	        String address =scan.next();
	        		
	        		
	        		
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, sname);
	        	   pstmt.setInt(2, sage);
	        	   pstmt.setNString(3, address);
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}





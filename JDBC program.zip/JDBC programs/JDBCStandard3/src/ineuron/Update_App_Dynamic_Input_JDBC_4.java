package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Update_App_Dynamic_Input_JDBC_4 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlUpdateQuery = "update student set address =? where sid= ?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlUpdateQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the address of the student :: ");
	    	        String address =scan.next();
	    	        
	    	        System.out.print("Enter the id of the student :: ");
	    	        int sid =scan.nextInt();
	    	  
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, address);
	        	   pstmt.setInt(2, sid);
	        	  
	        	   
	        	   System.out.println(sqlUpdateQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}





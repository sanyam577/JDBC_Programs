package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Insert_App_JDBC_1 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlInsertQuery = "insert into student(sname,sage,address)values(?,?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, "Lalitha");
	        	   pstmt.setInt(2, 24);
	        	   pstmt.setNString(3, "USA");
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	
	        	
	        	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}





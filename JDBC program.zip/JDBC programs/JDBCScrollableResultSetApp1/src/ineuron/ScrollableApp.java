package ineuron;

import java.io.IOException;

import java.sql.*;

import ineuronutil.jdbcutil;


/*
//this is an example is readable resultSet
public class ScrollableApp {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	        ResultSet resultSet=null;
	       
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");	
	        	
	        	
	        	if(connection!=null)
	        		stmt=connection.createStatement(); 
	        	
	        	String sqlQuery="select id,name,age,address from employees";
	        	if(stmt!=null)
	        		resultSet=stmt.executeQuery(sqlQuery);
	        	
	        	if(resultSet!=null)
	        		System.out.println("ID\tNAME\tAGE\tADDRESS");
	        	while(resultSet.next()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, resultSet);
				
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}
*/

//this is an example of scrollable resultSet

public class ScrollableApp {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	        ResultSet resultSet=null;
	       
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");	
	        	
	        	//ResultSet is of scrollable and updatable
	        	if(connection!=null)
	        		stmt=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE); 
	        	
	        	String sqlQuery="select id,name,age,address from employees";
	        	if(stmt!=null)
	        		resultSet=stmt.executeQuery(sqlQuery);
	        	
	        	
	        	if(resultSet!=null)
	        		System.out.println("MOVING IN FORWARD DIRECTION...");
	        		System.out.println("ID\tNAME\tAGE\tADDRESS");
	        	while(resultSet.next()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        	
                 System.out.println("********************************************");
	        	System.out.println("MOVING IN BACKWARD DIRECTION...");
	        	while(resultSet.previous()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        	
	        	System.out.println("********************************************");
	        	resultSet.first(); //cursor will be moved to first record
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        		
	        	System.out.println("********************************************");
		        	resultSet.last(); //cursor will be moved to last record
		        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
		        	
		        	resultSet.first();//takes the cursor to first row 
		        System.out.println("********************************************");
		            resultSet.absolute(3); //from the beginning of the resultSet
		            System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
		        	
		         System.out.println("********************************************");
		            resultSet.relative(2); //from the current position move downward 3+2=5th position
		            System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
		            
		            
		            
		            
		            
		            
		            resultSet.first();//takes the cursor to first row 
			      System.out.println("********************************************");
			        resultSet.absolute(4); //from the beginning of the resultSet to 4th position
			        System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
			        
			      System.out.println("********************************************");
			        resultSet.relative(-1); //takes the cursor to 3 because 4-1=3 current position was 4
			        System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));  
			        
			      System.out.println("********************************************");
			        resultSet.absolute(-1); //takes the cursor to downSide and begin from there
			        System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
			       
			      System.out.println("********************************************");
			        resultSet.absolute(-4); //takes the cursor to downSide and begin from there 3
			        System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
		        	   
		        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, resultSet);
				
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}












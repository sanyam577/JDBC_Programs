//this program will add batch of query

package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;



public class BatchUpdateUsingPreparedStatement {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlInsertQuery="insert into employees(name,age,address)values(?,?,?)";
	        	if(connection!=null) {
	        		pstmt=connection.prepareStatement(sqlInsertQuery);
	        	}
	           
	        
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        		while(true) {
	        			System.out.print("Enter the name :: ");
	        			String name= scan.next();
	        			System.out.print("Enter the age :: ");
	        			Integer age= scan.nextInt();
	        			System.out.print("Enter the address :: ");
	        			String address= scan.next();
	        			
	        			pstmt.setString(1,name);
	        			pstmt.setInt(2, age);
	        			pstmt.setNString(3, address);
	        			//one batch got created and query got added 
	        			pstmt.addBatch();
	        			
	        			System.out.println("Do you want to insert one more record [yes/no] ::");
	        			String option = scan.next();
	        			if(option.equalsIgnoreCase("no")) {
	        				break;
	        			}
	        			
	        		}
	        		//outside loop body
	        		
	        		//executing the query present in batch file
	        		pstmt.executeBatch();
	        		
	        		System.out.println("Record inserted successfully..");
	        		
	        	}
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}
















package MyBank;
import java.util.Scanner;

import Process.CheckBalance;
import Process.DepositeAmount;
import Process.Transaction;
import Process.Withdraw;
import Process.verification;
/*
 * @author Sanyam Singh
 */
public class BankApp {

	public static void main(String[] args) {
		int amount = 70000;
		System.out.println("***Welcome to INEURON Bank***\n");
		Scanner sc = new Scanner(System.in);
		verification v = new verification();
		v.verifyUser();
		
		
		if(verification.flag==true) {
		while(true) {
		System.out.print("1.Balance Check\n"
			    + "2.Deposit\n"
				+ "3.Withdraw\n"
				+ "4.Send Money\n"
				+ "5.Exit\n"
				+ "Enter your choice :");
		int x = sc.nextInt();
		
		if(x==1){
			amount = CheckBalance.Check(amount);
			continue;
		}
		else if(x==2){
			amount = DepositeAmount.Deposit(amount);
			continue;
		}
        else if(x==3){
        	amount = Withdraw.withdraw(amount);
        	continue;
		}
        else if(x==4){
        	amount = Transaction.Send(amount);
        	continue;
		}
        else if(x==5){
        	System.out.println("Thank you for visting our bank ");
			System.exit(0);
		}
        else {
        	System.out.println("Choose correct option from above list");
        }
		}
	}
		else {
			System.out.println("Invalid login credentials");
	        System.exit(0);
		}
		sc.close();
  }
	}

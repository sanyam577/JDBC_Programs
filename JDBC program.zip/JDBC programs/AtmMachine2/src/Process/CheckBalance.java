package Process;

public class CheckBalance {

	public static int Check(int amount) {
		System.out.println("Your Current Account Balance is Rs."+amount);		
	return amount;
	}

}

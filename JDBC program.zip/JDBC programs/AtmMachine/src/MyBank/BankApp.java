
package MyBank;
import java.util.Scanner;

import Process.BalanceCheck;
import Process.DepositeAmount;
import Process.Transaction;
import Process.Withdraw;
/*
 * @author Aniket Narode
 */
public class BankApp {

	public static void main(String[] args) {
		int amount = 50000;
		System.out.println("***Welcome to INEURON Bank***\n");
		Scanner sc = new Scanner(System.in);
		final String user ="user@123";
		final String passW ="pass@123";
		System.out.print("Enter User ID:");
		String id =sc.next();
		System.out.print("Enter User Password:");
		String passWord =sc.next();
		if(user.equals(id) && passW.equals(passWord)) {
		while(true) {
		System.out.print("1.Balance Check\n"
				+ "2.Deposit\n"
				+ "3.Withdraw\n"
				+ "4.Send Money\n"
				+ "5.Exit\n"
				+ "Enter your choice :");
		int x = sc.nextInt();
		
		if(x==1){
			amount = BalanceCheck.Check(amount);
			continue;
		}
		else if(x==2){
			amount = DepositeAmount.Deposit(amount);
			continue;
		}
        else if(x==3){
        	amount = Withdraw.withdraw(amount);
        	continue;
		}
        else if(x==4){
        	amount = Transaction.Send(amount);
        	continue;
		}
        else if(x==5){
        	System.out.println("Thank you");
			System.exit(0);
		}
        else {
        	System.out.println("Invalid Input Please try again");
        }
		}
	}
		else {
			System.out.println("Invalid login credentials");
	        System.exit(0);
		}
		sc.close();
  }
	}
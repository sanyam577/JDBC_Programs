package Process;

import java.util.Scanner;

public class DepositeAmount {

	public static int Deposit(int amount) {
		Scanner sc =new Scanner(System.in);
		System.out.print("Please Enter the amount to Deposit Rs.");
		int deposit = sc.nextInt();
		amount += deposit;
		System.out.println("Rs."+deposit+" is deposited into your Account");
		System.out.println("Current Available Balance is Rs."+ amount);
		return amount;
		}
}

package Process;

import java.util.Scanner;

public class Withdraw {
	
public static int withdraw(int amount) {
		
		System.out.print("Enter the Amount you want to withdraw Rs.");
		Scanner sc= new Scanner(System.in);
		int withdraw =sc.nextInt();
		if(withdraw<amount)
		{
			amount=amount-withdraw;
			System.out.println("Rs."+ withdraw+" is withdraw from your Account");
			System.out.println("Current Available Balance is Rs."+ amount);
			return amount;
		}
		else
		{
			System.out.println("Low Balance");
			System.out.println("Current Available Balance is Rs."+ amount);
			return amount;
		}
	}

}

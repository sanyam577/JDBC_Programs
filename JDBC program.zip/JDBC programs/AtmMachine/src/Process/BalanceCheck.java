package Process;

public class BalanceCheck {

	public static int Check(int amount) {
		System.out.println("Your Current Account Balance is Rs."+amount);		
	return amount;
	}

}

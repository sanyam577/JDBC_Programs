package atm;

import java.util.Scanner;

public class MainClass {
	public static void main(String [] args)throws Exception {
		Scanner scan = new Scanner(System.in);
		boolean flag = false;
		while(flag) {
			System.out.println("*************************************");
			System.out.println("*************************************");
			System.out.println("*************************************");
			System.out.println("+++++ Welcome To My Bank +++++");
			System.out.println();
			System.out.println("1.Withdraw");
			System.out.println("2.Deposit");
			System.out.println("3.Check Balance");
			System.out.println("4.Exit");
			
			System.out.println("Enter your option");
			int choice =scan.nextInt();
			if(choice==1) {
				Withdraw w =new Withdraw();
				Accessing ac=new Accessing();
				ac.permit(w);
			}
			
			else if(choice==2) {
				Deposit d =new Deposit();
				Accessing ac1=new Accessing();
				ac1.permit(d);
			}
			else if(choice==3) {
				Balance b =new Balance();
				Accessing ac2=new Accessing();
				ac2.permit(b);
			}
			else {
				flag =false;
				System.exit(0);
				
			}
			
		}
		
	}

}

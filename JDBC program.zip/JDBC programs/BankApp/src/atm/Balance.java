package atm;

public class Balance extends Server {
    static void afterWithdraw(double amount) {
	bankBalance=bankBalance-amount;
}
    static void afterDeposit(double amount) {
    	bankBalance=bankBalance+amount;
    }
    void verify() throws NotMatchingException{
    	if(uid==id &&upw==pw) {
    		System.out.println("Your bank balance is :: "+bankBalance);
    	}
    	else {
    		NotMatchingException ne = new NotMatchingException();
    		throw ne;
    	}
    } 
    
}

package atm;

public class Withdraw extends Server{
	@Override
	void verify() throws Exception, NotMatchingException{
		if(uid==id &&upw==pw) {
			System.out.println("Enter the amount to be withdraw");
			amount=scan.nextDouble();
			System.out.println("Loading........Please wait");
			Thread.sleep(4000);
			System.out.println("Your ammount has been withdrawl");
			Balance.afterWithdraw(amount);
			System.out.println("Your bank balance is "+bankBalance);
		}
		else {
    		NotMatchingException ne = new NotMatchingException();
    		throw ne;
    	}
	}
	

}

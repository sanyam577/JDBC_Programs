package atm;

import java.util.Scanner;

public abstract class Server {

	public int uid = 840087;
	public int upw = 9682;
	public int id;
	public int pw;
	public double amount;
	static double bankBalance=20000;
	Scanner scan = new Scanner(System.in);
	void input() {
		System.out.println("Enter the UserId");
		id=scan.nextInt();
		System.out.println("Enter the password");
		pw=scan.nextInt();
	}
	abstract void verify() throws Exception; 

}

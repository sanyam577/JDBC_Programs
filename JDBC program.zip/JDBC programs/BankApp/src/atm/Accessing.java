package atm;

class NotMatchingException extends Exception{
	public NotMatchingException() {
		System.out.println("Exception found");
	}
}

public class Accessing {
	void permit (Server s)throws Exception{
		try {
			s.input();
			s.verify();
		}
		catch(InterruptedException | NotMatchingException nme) {
			System.out.println("Invaild User Details");
			try {
				s.input();
				s.verify();
			}
			catch(NotMatchingException nme1) {
				System.out.println("Again Invaild User Details");
				try {
					s.input();
					s.verify();
				}
				catch(NotMatchingException nme2) {
					System.out.println("No more access, wait for next day");
				}
			}
			finally {
				System.out.println("Visit your nearest branch");
			}
		}
	}

}

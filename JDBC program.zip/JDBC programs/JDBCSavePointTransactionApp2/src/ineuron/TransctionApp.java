package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class TransctionApp {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	       
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	 System.out.println("Transaction started");
	        	 
	        	 if(connection!=null)
	        		 stmt=connection.createStatement();
	        	 
	        	connection.setAutoCommit(false);
	        	stmt.executeUpdate("insert into politicians(name,party)values('modi','Bjp')");
	        	stmt.executeUpdate("insert into politicians(name,party)values('KCR','TRS')");
	        	Savepoint sp = connection.setSavepoint(); // if data is wrong it will role back from this query 
	        	stmt.executeUpdate("insert into politicians(name,party)values('siddu','Bjp')");
	        	 System.out.println("Oh something went wrong during insersetion..");
	            connection.rollback(sp);
	            System.out.println("Operations are rolled back to the save point");
	            connection.commit();
	            System.out.println("Transaction done");
	            
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, null);
				
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}





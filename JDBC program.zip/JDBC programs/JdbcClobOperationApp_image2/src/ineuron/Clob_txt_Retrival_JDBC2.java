
package ineuron;
import java.io.IOException;
import java.io.*;
import java.sql.*;

import java.util.Scanner;

import org.apache.commons.io.IOUtils;

import ineuronutil.jdbcutil;



public class Clob_txt_Retrival_JDBC2   {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        ResultSet resultSet=null;
	        int id=0;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	String sqlSelectQuery = "select id, name, history from cities where id=?";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlSelectQuery);
	        	
	        	if(pstmt!=null) {
	        		
                    scan = new Scanner(System.in);
	    	        
	    	        System.out.print("Enter the id of the city :: ");
	    	         id =scan.nextInt();
	        
	        		//use recompiled query to set values
	        	   pstmt.setInt(1, id);
	        	   
	        	   
	        	   resultSet =pstmt.executeQuery();
	        	   if(resultSet!=null) {
		      
		        		if(resultSet.next()) {
		        			System.out.println("ID\tNAME\tHISTORY");
		                     id = resultSet.getInt(1);
		                    String name =resultSet.getNString(2);
		                    Reader reader = resultSet.getCharacterStream(3);  //is means inputStream
		                    
		                 File file = new File("history_copied.txt");
		                 FileWriter writer = new FileWriter(file);
		                
		                
		                 
		                
		                
		                 IOUtils.copy(reader, writer);
		                 writer.close();   
		        		System.out.println(id+"\t"+name+"\t"+ file.getAbsolutePath());
		        		}
		        		
		        		else {
		        			System.out.println("Record not found of this id ::"+id);
		        		}
		        	}
	        	   
	        	}
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, resultSet);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	}
}


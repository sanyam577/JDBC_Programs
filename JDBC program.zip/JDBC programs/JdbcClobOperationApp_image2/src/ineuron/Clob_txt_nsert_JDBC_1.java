
package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;



public class Clob_txt_nsert_JDBC_1 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        PreparedStatement pstmt = null;
	        Scanner scan = null;
	        String txtLoc=null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	
	        	String sqlInsertQuery = "insert into cities(name,history)values(?,?)";
	        	if(connection!=null)
	        		pstmt =connection.prepareStatement(sqlInsertQuery);
	        	if(pstmt!=null) {
	        		scan = new Scanner(System.in);
	        		//Read the input from the user
	    	        System.out.print("Enter the name of the city :: ");
	    	        String name =scan.next();
	    	      
	    	        System.out.print("Enter pdf location :: ");
	    	        txtLoc =scan.next();
	    			
	        		
	        		//use recompiled query to set values
	        	   pstmt.setNString(1, name);
	        	   pstmt.setCharacterStream(2, new FileReader(new File(txtLoc)));
	        	   
	        	  
	        	   
	        	   System.out.println(sqlInsertQuery);
	        	   //execute the query
	        	   int rowCount =pstmt.executeUpdate();
	        	   System.out.println("No of rows updated is :: "+rowCount);
	        	   
	        	}
	        	
	        	
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, pstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}















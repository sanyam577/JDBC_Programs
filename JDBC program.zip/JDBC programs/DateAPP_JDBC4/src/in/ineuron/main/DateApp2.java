package in.ineuron.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;


public class DateApp2 {

	public static void main(String[] args) throws Exception {
		
		//Read the input from the user
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the date:: (dd-MM-yyyy)");
		String sdate = scan.next();
		
		//Convert the date from String format to java.util.Date
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); //SimpleDateFormat is a concrete class
	    java.util.Date uDate = sdf.parse(sdate);	                                                           //for formatting and parsing dates in a locale-sensitive manner. 
		
        //Convert java.util.Date into java.sql.Date
	    long value = uDate.getTime();
	    java.sql.Date sqlDate =new java.sql.Date(value);
	    
	    //Printing all the 3 format of Date
	    System.out.println("String format date is ::"+sdate);
	    System.out.println("Util Date is :: "+uDate);
	    System.out.println("sqlDate is :: "+sqlDate);
	    
	}

}

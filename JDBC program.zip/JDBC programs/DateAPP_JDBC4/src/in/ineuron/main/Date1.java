package in.ineuron.main;

public class Date1 {

	public static void main(String[] args) {
		
		//java.util.Date-> we use to store both date and time information
		java.util.Date udate = new java.util.Date();
		System.out.println("utilDate format is :: "+udate);
		
		long value = udate.getTime();
		System.out.println("Information about date in millisecond:: "+value);
		
		//java.sql.Date-> we use to store Date information
		java.sql.Date sqlDate = new java.sql.Date(value);
		System.out.println("sqlDate is :: "+sqlDate);

	}

}

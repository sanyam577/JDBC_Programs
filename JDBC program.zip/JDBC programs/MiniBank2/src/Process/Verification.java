package Process;

import java.util.Scanner;

public class Verification {

	 public static boolean flag = false;
	Scanner scan= new Scanner (System.in);
	
	public final String UserId="Tiwari";
	public final  String UserPassword = "Pass123";
	
	public  void  verifyUser() 
	{
		System.out.println("Please enter your User_Name");
		String uid= scan.next();
		System.out.println("Please enter your Password");
		String upass= scan.next();
		
		if(UserId.equals(uid) && UserPassword.equals(upass)) 
		{
			System.out.println("THANKS FOR YOUR VARIFICATON ");
			System.out.println("********************************");
			flag=true;
			
		}
		
		
}
}
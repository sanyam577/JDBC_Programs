package ineuron;

import java.sql.*;
import java.util.Scanner;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.FilteredRowSet;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.JoinRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import javax.sql.rowset.WebRowSet;

public class JdbcRowSet_Delete_App4 {

	public static void main(String[] args) throws Exception {
	  
		RowSetFactory rsf = RowSetProvider.newFactory();
		CachedRowSet crs = rsf.createCachedRowSet();
		
		//setting url, username,password
		crs.setUrl("jdbc:mysql:///octbatch");
		crs.setUsername("root");
		crs.setPassword("Kalhans8400@");
		
		//setting a command for execution 
		crs.setCommand("select id,name,age,address,salary from student");
		crs.execute();
		
		while(crs.next()) {
			int actualSalary = crs.getInt(5);
			if(actualSalary<5000) {
				crs.deleteRow();
			}
		}
		System.out.println("Records deleted succesfully...");
		crs.moveToCurrentRow();
		crs.acceptChanges();
		
		crs.close();
		
			}		
	}	 


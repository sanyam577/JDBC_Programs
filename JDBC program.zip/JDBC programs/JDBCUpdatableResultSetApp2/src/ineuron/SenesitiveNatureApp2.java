package ineuron;

import java.io.IOException;

import java.sql.*;

import ineuronutil.jdbcutil;


//this is an example of scroll sensitive and scroll insensitive

public class SenesitiveNatureApp2 {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	        ResultSet resultSet=null;
	       
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");	
	        	
	        	//ResultSet is of scrollable and updatable
	        	if(connection!=null)
	       // 		stmt=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);  //any change happen in database will 
	        		                                                               //not be reflected here after pressing enter on console (INSENSITIVE)
	        		
	        		stmt=connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE); //any change happen in database will 
                                                                                   //be reflected here after pressing enter on console (SENSITIVE)
	        	
	        	String sqlQuery="select id,name,age,address from employees";
	        	if(stmt!=null)
	        		resultSet=stmt.executeQuery(sqlQuery);
	        	
	        	
	        	if(resultSet!=null)
	        		System.out.println("Record before updation");
	        		System.out.println("MOVING IN FORWARD DIRECTION...");
	        		System.out.println("ID\tNAME\tAGE\tADDRESS");
	        	while(resultSet.next()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        	
	        	System.out.println();
	        	
	        	System.out.println("Application is in pausing state, please update database....");
	        	System.in.read();
	        	System.out.println("Records after updation..");
	        	resultSet.beforeFirst(); //takes the cursor to before first row
	        	System.out.println("ID\tNAME\tAGE\tADDRESS");
	        	while(resultSet.next()) {
	        		resultSet.refreshRow(); //to get the updated value
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        		  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, resultSet);
				
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}












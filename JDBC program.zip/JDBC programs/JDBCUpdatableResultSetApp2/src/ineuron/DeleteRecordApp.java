package ineuron;

import java.io.IOException;

import java.sql.*;

import ineuronutil.jdbcutil;


//this is an example of updatable resultSet

public class DeleteRecordApp {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	        ResultSet resultSet=null;
	       
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");	
	        	
	        	//ResultSet is of scrollable and updatable
	        	if(connection!=null)
	       // 		stmt=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE); 
	        		stmt=connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE); 
	        	
	        	String sqlQuery="select id,name,age,address from employees";
	        	if(stmt!=null)
	        		resultSet=stmt.executeQuery(sqlQuery);
	        	
	        	
	        	if(resultSet!=null)
	        		System.out.println("Record before deletion...");
	        		System.out.println("MOVING IN FORWARD DIRECTION...");
	        		System.out.println("ID\tNAME\tAGE\tADDRESS");
	        	while(resultSet.next()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
	        	}
	        	
	        	System.out.println();
	        	//performing delete operation using resultSet
	        	resultSet.last(); //cursor in last row
	        	resultSet.deleteRow(); //perform deletion operation
	        	
	        	resultSet.beforeFirst(); //taking the code to BFR
	        	System.out.println("Record after deletion...");
        		System.out.println("MOVING IN FORWARD DIRECTION...");
        		System.out.println("ID\tNAME\tAGE\tADDRESS");
        	while(resultSet.next()) {
        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getNString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getNString(4));
        	}
	        	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, resultSet);
				
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}












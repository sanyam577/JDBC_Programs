package ineuronutil;

import java.io.*;
import java.sql.*;

import java.util.*;

public class jdbcutil {

	private jdbcutil() {} //constructor
	public static Connection getJdbcConnection()throws SQLException, IOException {
         FileInputStream fis= new FileInputStream("src\\in\\ineuron\\properties\\application.properties");
		Properties properties = new Properties();
		properties.load(fis);
		
		
		//step-2 establishing connection
		 String url =properties.getProperty("url");  
	        String userName=properties.getProperty("userName");
	        String passWord=properties.getProperty("passWord");
	        Connection connection = DriverManager.getConnection(url,userName,passWord); 
	        System.out.println("the implementation class name is "+connection.getClass().getName());
            return connection;
	}
	
	//step-6 closing the resources
	public static void cleanUp(Connection connection,Statement statement,ResultSet resultSet)throws SQLException{
		if(connection!=null) {
			connection.close();
		}
		
		if(statement!=null) {
			statement.close();
		}
		if(resultSet!=null) {
			resultSet.close();
		}
	}

}

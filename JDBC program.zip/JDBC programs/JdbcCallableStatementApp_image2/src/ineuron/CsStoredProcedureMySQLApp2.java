
package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;


/*
 // call by name
USE `octbatch`;
DROP procedure IF EXISTS `P_GET_PRODUCT_BY_NAME`;

DELIMITER $$
USE `octbatch`$$
CREATE PROCEDURE `P_GET_PRODUCT_BY_NAME` (IN name1 VARCHAR(45), IN name2 VARCHAR(45) )
BEGIN
       SELECT pid, pname, price,qty FROM products WHERE pname IN (name1,name2);
END$$

DELIMITER ;




CALL `P_GET_PRODUCT_BY_NAME`(fossil,tissot);


 */


public class CsStoredProcedureMySQLApp2 {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        CallableStatement cstmt = null;
	        ResultSet resultSet = null;
	        Scanner scan = null;
	        String prod1 =null;
	        String prod2 =null;
	        boolean flag = false;
	        
	        String storedProcedureCall="{CALL P_GET_PRODUCT_BY_NAME(?,?)}";
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	if(connection!=null) {
	        		
					cstmt=connection.prepareCall(storedProcedureCall);
	        	}
	        	scan = new Scanner(System.in);
	        	if(scan!=null) {
	        		System.out.println("Enter the 1st product name :: ");
	        		prod1=scan.next();
	        		
	        		System.out.println("Enter the 2nd product name :: ");
	        		prod2=scan.next();
	        	}
	        	
	        	//setting the input values  
	          if(cstmt!=null) {
	        	  cstmt.setString(1, prod1);
	        	  cstmt.setString(2, prod2);
	          }	
	        
	        
	        //run the stored procedure
	        if(cstmt!=null) {
	        	  cstmt.execute();
	          }	
	        //Retrieve the result
	        if(cstmt!=null) {
	        	  resultSet= cstmt.getResultSet();
	          }	
	        //process the resultSet
	        if(resultSet!=null) {
	        	System.out.println("PID\tPNAME\tPPRICE\tQTY");
	        	while(resultSet.next()) {
	        		System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getInt(4));
	        		flag= true;
	        	}
	        }
	        //displaying the nature of result
	        if(flag) {
	        	System.out.println("Record Available and displayed");
	        }else {
	        	System.out.println("Record not Available and displayed");
	        }
	        
	        
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, cstmt, resultSet);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}
















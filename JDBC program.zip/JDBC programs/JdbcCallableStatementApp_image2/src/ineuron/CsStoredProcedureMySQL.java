
package ineuron;

import java.io.*;

import java.io.IOException;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import ineuronutil.jdbcutil;

/*
 //call by id
USE `octbatch`;
DROP procedure IF EXISTS `P_GET_PRODUCT_DETAILS_BY_ID`;

DELIMITER $$
USE `octbatch`$$
CREATE PROCEDURE `P_GET_PRODUCT_DETAILS_BY_ID` (IN id INT, OUT name VARCHAR(45), OUT rate INT, OUT qnt INT)
BEGIN
    select pname, price,qty into name,rate,qnt from products where pid=id;
END$$

DELIMITER ;

use octbatch;
CALL P_GET_PRODUCT_DETAILS_BY_ID(1,@name,@rate,@qnt);
select @name, @rate ,@qnt;
*/


/*
public class CsStoredProcedureMySQL {

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        CallableStatement cstmt = null;
	        Scanner scan = null;
	        Integer id =null;
	        
	        String storedProcedureCall="{CALL P_GET_PRODUCT_DETAILS_BY_ID(?,?,?,?)}";
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	if(connection!=null) {
	        		
					cstmt=connection.prepareCall(storedProcedureCall);
	        	}
	        	scan = new Scanner(System.in);
	        	if(scan!=null) {
	        		System.out.println("Enter the product id :: ");
	        		id=scan.nextInt();
	        	}
	        	
	        	//setting the input values  
	          if(cstmt!=null) {
	        	  cstmt.setInt(1, id);
	          }	
	        
	        //Setting the DataType of output values
	        if(cstmt!=null) {
	        	cstmt.registerOutParameter(2, Types.VARCHAR);
	        	cstmt.registerOutParameter(3, Types.INTEGER);
	        	cstmt.registerOutParameter(4, Types.INTEGER);
	        }
	        //run the stored procedure
	        if(cstmt!=null) {
	        	  cstmt.execute();
	          }	
	        //Retrieve the result
	        if(cstmt!=null) {
	        	  System.out.println("Product name is :: "+cstmt.getString(2));
	        	  System.out.println("Product rate is :: "+cstmt.getInt(3));
	        	  System.out.println("Product quantity is :: "+cstmt.getInt(4));
	          }	
	        
	        
	        
	        
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, cstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}

*/





//using private static final to avoid multiple if blocks

public class CsStoredProcedureMySQL {
	
	 private static final String storedProcedureCall="{CALL P_GET_PRODUCT_DETAILS_BY_ID(?,?,?,?)}";

	public static void main(String[] args)throws Exception {
		
	        Connection connection = null;
	        CallableStatement cstmt = null;
	        Scanner scan = null;
	        Integer id =null;
	        
	      
	       
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");
	        	
	        	if(connection!=null) {
	        		
					cstmt=connection.prepareCall(storedProcedureCall);
	        	}
	        	scan = new Scanner(System.in);
	        	if(scan!=null) {
	        		System.out.println("Enter the product id :: ");
	        		id=scan.nextInt();
	        	}
	        	
	        	  
	          if(cstmt!=null) {
	        	//setting the input values
	        	  cstmt.setInt(1, id);
	          	
	        
	        //Setting the DataType of output values
	            cstmt.registerOutParameter(2, Types.VARCHAR);
	        	cstmt.registerOutParameter(3, Types.INTEGER);
	        	cstmt.registerOutParameter(4, Types.INTEGER);
	       
	        //run the stored procedure
	            cstmt.execute();
	         
	        //Retrieve the result
	        
	        	  System.out.println("Product name is :: "+cstmt.getString(2));
	        	  System.out.println("Product rate is :: "+cstmt.getInt(3));
	        	  System.out.println("Product quantity is :: "+cstmt.getInt(4));
	          }	
	        
	        
	        
	        
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, cstmt, null);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}

















package ineuron;
import java.io.IOException;

import java.sql.*;

import java.util.Scanner;

import ineuronutil.jdbcutil;



public class TransctionApp {

	public static void main(String[] args) {
		
	        Connection connection = null;
	        Statement stmt = null;
	        ResultSet resultSet=null;
	        Scanner scan=null;
	        ResultSet rs=null;
	       
	        
	        try {
	        	connection =jdbcutil.getJdbcConnection();
	        	System.out.println("connection established");	
	        	System.out.println("Data before transaction..");
	        	
	        	if(connection!=null)
	        		stmt=connection.createStatement();
	        	if(stmt!=null) 
	        		resultSet=stmt.executeQuery("select name,balance from accounts");
	        	if(resultSet!=null) {
	        		System.out.println("NAME\tBALANCE");
	        		while(resultSet.next()) {
	        		System.out.println(resultSet.getString(1)+"\t"+resultSet.getInt(2));
	        	 }
	        	}
	        //transaction begins
	        	System.out.println("\n Transction begins...");
	        	connection.setAutoCommit(false);
	       //Prepare the operation as single unit	
	        	stmt.executeUpdate("update accounts set balance = balance-5000 where name ='sachin'");
	        	stmt.executeUpdate("update accounts set balance = balance+5000 where name ='dhoni'");
	        	
	        	System.out.print("can you please confirm the transaction of 5000INR...[YES/No]");
	        	scan=new Scanner(System.in);
	        	String option =scan.next();
	        	if(option.equalsIgnoreCase("yes")) {
	        		connection.commit();
	        	}else {
	        		connection.rollback();
	        	}
	        	
	        	System.out.println("\nData after transaction..");
	            rs= stmt.executeQuery("select name,balance from accounts");
	        	if(rs!=null) {
	        		System.out.println("NAME\tBALANCE");
	        		while(rs.next()) {
	        		System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
	        	 }
	        	}
	        	  	
	        }
	        catch(IOException i) {
	        	i.printStackTrace();
	        	}
	        catch(SQLException se) {
	        	se.printStackTrace();
	        }catch(Exception e) {
	        	e.printStackTrace();
	        	}
	        finally {
	        	try {
					jdbcutil.cleanUp(connection, stmt, resultSet);
					jdbcutil.cleanUp(null, null, rs);
					scan.close();
					System.out.println("closing the resources");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        
	       

	}

}





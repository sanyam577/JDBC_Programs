package newInstance_vs_new;

class Student{
	static {
		System.out.println("static block is loaded or .class file (Student .class file) is loaded ");
	}
	public Student(){
		System.out.println("Student Constructor is called");
	}
}
public class LoadClass_Explicitily {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String className=args[0]; //take the name of the class from command line
		 //load the class file explicitily
		Class c = Class.forName(className);
		
		//for the loaded class, object is created by using zero param constructor only
		// newInstance() will only search for zero param constructor
		
		Object obj = c.newInstance();
		Student std =(Student)obj;
		System.out.println(std);
 		
         
	}

}

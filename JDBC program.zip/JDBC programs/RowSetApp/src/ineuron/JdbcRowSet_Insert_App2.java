package ineuron;

import java.sql.*;
import java.util.Scanner;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.FilteredRowSet;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.JoinRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import javax.sql.rowset.WebRowSet;

public class JdbcRowSet_Insert_App2 {

	public static void main(String[] args) throws Exception {
	  
		RowSetFactory rsf = RowSetProvider.newFactory();
		JdbcRowSet jrs = rsf.createJdbcRowSet();
		
		//setting url, username,password
		jrs.setUrl("jdbc:mysql:///octbatch");
		jrs.setUsername("root");
		jrs.setPassword("Kalhans8400@");
		
		//setting a command for execution 
		jrs.setCommand("select id,name,age,address from student");
		jrs.execute();
		
		Scanner scan = new Scanner(System.in);
		jrs.moveToInsertRow();
		
		while(true) {
			System.out.println("Enter the name");
			String name= scan.next();
			
			System.out.println("Enter the age");
			Integer age= scan.nextInt();
			
			System.out.println("Enter the address");
			String address= scan.next();
			
			jrs.updateString(2, name);
			jrs.updateInt(3, age);
			jrs.updateString(4, address);
			
			jrs.insertRow();
			
			System.out.println("Record inserted successfully");
			System.out.println("do you want to insert one more record [Yes/No]");
			String option = scan.next();
			if(option.equalsIgnoreCase("No")) {
				break;
			}
			
		}
		scan.close();
		jrs.close();	
	}	 

}

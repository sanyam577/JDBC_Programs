package ineuron;

import java.sql.*;
import java.util.Scanner;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.FilteredRowSet;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.JoinRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import javax.sql.rowset.WebRowSet;

public class JdbcRowSet_Delete_App4 {

	public static void main(String[] args) throws Exception {
	  
		RowSetFactory rsf = RowSetProvider.newFactory();
		JdbcRowSet jrs = rsf.createJdbcRowSet();
		
		//setting url, username,password
		jrs.setUrl("jdbc:mysql:///octbatch");
		jrs.setUsername("root");
		jrs.setPassword("Kalhans8400@");
		
		//setting a command for execution 
		jrs.setCommand("select id,name,age,address,salary from student");
		jrs.execute();
		
		while(jrs.next()) {
			int actualSalary = jrs.getInt(5);
			if(actualSalary<5000) {
				jrs.deleteRow();
			}
		}
		System.out.println("Records deleted succesfully...");
		jrs.close();
		
			}		
	}	 

